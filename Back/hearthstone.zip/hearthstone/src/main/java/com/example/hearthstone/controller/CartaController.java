package com.example.hearthstone.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.hearthstone.entity.Carta;
import com.example.hearthstone.repository.CartaRepository;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/cartas") // Ruta base para todas las solicitudes relacionadas con cartas
public class CartaController {

    private final CartaRepository cartaRepository;

    @Autowired
    public CartaController(CartaRepository cartaRepository) {
        this.cartaRepository = cartaRepository;
    }

    @GetMapping
    public List<Carta> obtenerTodasLasCartas() {
        return cartaRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Carta> obtenerCarta(@PathVariable Long id) {
        Optional<Carta> carta = cartaRepository.findById(id);
        return carta.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Carta crearCarta(@RequestBody Carta carta) {
        return cartaRepository.save(carta);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Carta> actualizarCarta(@PathVariable Long id, @RequestBody Carta carta) {
        Optional<Carta> cartaExistente = cartaRepository.findById(id);
        if (cartaExistente.isPresent()) {
            carta.setId(id);
            cartaRepository.save(carta);
            return ResponseEntity.ok(carta);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarCarta(@PathVariable Long id) {
        Optional<Carta> cartaExistente = cartaRepository.findById(id);
        if (cartaExistente.isPresent()) {
            cartaRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Otros métodos y lógica adicional según tus necesidades
}
